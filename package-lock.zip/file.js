import { appendFile,readFile } from "fs";

const fileName = "example.txt";

export const fileWrite=(data)=>{
    appendFile(fileName, JSON.stringify(data)+'\n', (err) => {
        if (fileName) {
          console.log("Data written successfully!");
          return true;
        } else {
          console.error("Error writing to file:", err);
          return false
        }
      });
};
// export const fileRead=()=>{
//     readFile(fileName,'utf8',(err,data) => {
//         if (err) {
//           console.error("Error read to file:", err);
//           return err;
//         } 
//         console.log(data);
//         return data;
        
//       });

//     // readFile(fileName, 'utf-8', (readErr, fileData) => {
//     //     if (readErr) {
//     //       return console.error('Error reading file:', readErr);
//     //     }
//     //     console.log('File content:', fileData);
//     //     });
// }


export const fileRead = () => {
    return new Promise((resolve, reject) => {
        readFile(fileName, 'utf8', (err, data) => {
            if (err) {
                console.error("Error reading file:", err);
                return reject(err); // Reject the promise with the error
            }
            return resolve(data); // Resolve the promise with the data
            resolve(data); // Resolve the promise with the file data
        });
    });
};