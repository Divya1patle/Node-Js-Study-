// import https from 'https';
//  const server=https.createServer();
//  server.listen(PORT,()=>{
//     console.log(`SERVER IS RUNNING ON PORT ${PORT}`)
//  });

import express from "express";
import {fileWrite,fileRead}  from "./file.js"
const app = express();
const PORT = 9091;
app.listen(PORT, () => {
  console.log("server is running on port 9091");
});

app.use(express.json());

// routes
app.get('/get', async (_,res) => { // Change here: added req as the first parameter
    try {
        let data = await fileRead();
        console.log(data);
        
        res.status(200).send({ data: data, status: 200 });
    } catch (error) {
        console.error('Error reading file:', error);
        res.status(500).send({ error: 'Internal Server Error', status: 500 });
    }
});
// restful API
// GET,POST,PUT,DELETE.PATCH========CRUD


app.post('/post',(req,res)=>{
    const data=req.body;
    fileWrite(data);
    res.status(200).send({name:req.body,status:200});
});


app.put('/put',(req,res)=>{
    console.log('nishant put method');
    let abc=req.body;
    console.log(abc)
    abc=abc.DIVYA +" "+"divyabestie";

    res.status(200).send({name:abc,status:200});
});

app.delete('/delete',()=>{
    console.log('delete method');
    res.status(200).send({status:200});
})

